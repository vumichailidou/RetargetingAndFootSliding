import bpy


def apply_footplant(
    obj_target_name: str,
    bone_target_name: str,
    target_toe_base: str = None,
    scopes=None,
    absolute_toe_correction: bool = False,
) -> bool:
    """Apply footplant to a single target bone.

    :param scopes: optional iterable of (start, end) frame ranges. If None, uses
                   scene.my_settings.scopes_add.
    """

    scene = bpy.context.scene
    frame_start = scene.frame_start
    frame_end = scene.frame_end

    print(f"Frame Start: {frame_start}, Frame End: {frame_end}")

    # get target objects/bones
    try:
        obj_target = bpy.data.objects[obj_target_name]
        bone_target_IK = obj_target.pose.bones[bone_target_name]
    except Exception as e:
        print(f"Ziel nicht gefunden: {e}")
        return False

    target_toe_base_bone = None
    if target_toe_base:
        try:
            target_toe_base_bone = obj_target.pose.bones[target_toe_base]
        except Exception:
            target_toe_base_bone = None

    settings = bpy.context.scene.my_settings

    # Build scopes_ranges from passed scopes or UI
    scopes_ranges = []
    if scopes is None:
       return False
    else:
        for s in scopes:
          #  start = max(frame_start, int(s[0]))
          #  end = min(frame_end, int(s[1]))
          #  if end < start:
          #      continue
            scopes_ranges.append((int(s[0]), int(s[1])))

    # build flat list of frames
    frames_triggered = []
    for scope in scopes_ranges:
        for f in range(scope[0], scope[1] + 1):
            frames_triggered.append(f)

    frames_triggered = sorted(set(frames_triggered))
    if not frames_triggered:
        print("Keine Scopes definiert oder Frames vorhanden.")
        return True

    for scope in scopes_ranges:
        for f in range(scope[0], scope[1] + 1):
            scene.frame_set(f)
            loc = bone_target_IK.location.copy()
            print (f, loc)

    print ("pause")

    # Build framesScope for smoothing (list of representative frames)
    framesScope = []
    framesScope.append(frames_triggered[0])
    framesScope.append(frames_triggered[-1])
    old_frame_id = frames_triggered[0] - 1
    for fr in frames_triggered:
        if old_frame_id == (fr - 1):
            old_frame_id = fr
        else:
            framesScope.append(old_frame_id)
            framesScope.append(fr)
            old_frame_id = fr

    # Freeze per-scope
    bpy.ops.object.mode_set(mode='POSE')
   # scene.frame_set(scopes_ranges[0][0])
   # ref_loc = bone_target_IK.location.copy()
    for scope in scopes_ranges:

        scene.frame_set(scope[0])
        ref_loc = bone_target_IK.location.copy()
        for f in range(scope[0], scope[1] + 1):
            scene.frame_set(f)
            loc = bone_target_IK.location.copy()
            if getattr(settings, 'freeze_x', False):
                loc.x = ref_loc.x
            if getattr(settings, 'freeze_y', False):
                loc.y = ref_loc.y
            if getattr(settings, 'freeze_z', True):
                loc.z = ref_loc.z
            bone_target_IK.location = loc
            try:
                bone_target_IK.lock_location = (False, False, False)
            except Exception:
                pass
            bone_target_IK.keyframe_insert(data_path="location", frame=f)

    bpy.context.view_layer.update()

    for scope in scopes_ranges:
        for f in range(scope[0], scope[1] + 1):
            scene.frame_set(f)
            loc = bone_target_IK.location.copy()
            print (f, loc)

    # Toe correction -> make toe world Z == 0 (absolute) or keep previous behavior
    if target_toe_base_bone is not None:
        if absolute_toe_correction:
            for scope in scopes_ranges:
                for f in range(scope[0], scope[1] + 1):
                    scene.frame_set(f)
                    fertig_world = (obj_target.matrix_world @ target_toe_base_bone.head)
                    diff = fertig_world.z
                    loc = bone_target_IK.location.copy()
                    loc.z += -diff
                    bone_target_IK.location = loc
                    bone_target_IK.keyframe_insert(data_path="location", frame=f)

            for scope in scopes_ranges:
                for f in range(scope[0], scope[1] + 1):
                    scene.frame_set(f)
                    print(f, (obj_target.matrix_world @ target_toe_base_bone.head))
        else:
           return False

    # Smooth curves
    if not obj_target.animation_data or not obj_target.animation_data.action:
        print("Keine Animation/Action gefunden.")
        return True

    action = obj_target.animation_data.action
    fcurve_z = None
    fcurve_x = None
    fcurve_y = None
    data_path = f'pose.bones["{bone_target_name}"].location'



    for layer in action.layers:
        for strip in layer.strips:
            for channel in strip.channelbags:
                for fc in channel.fcurves:
                    fc.select = False
                    if fc.data_path == data_path and fc.array_index == 2:
                        fcurve_z = fc
                    if fc.data_path == data_path and fc.array_index == 0:
                        fcurve_x = fc
                    if fc.data_path == data_path and fc.array_index == 1:
                        fcurve_y = fc
                    if fcurve_x is not None and fcurve_y is not None and fcurve_z is not None:
                        break

    if fcurve_z is None or fcurve_x is None or fcurve_y is None:
        print("Nicht alle F-Curves gefunden (X/Y/Z).")
        return True

    def smooth_curve(fcurve, frames_scope, strength=0.5, radius=2):
        points = fcurve.keyframe_points
        if len(points) < 3:
            return
        for scope in frames_scope:
            indices_to_smooth = set()
            min_f = scope - radius
            max_f = scope + radius
            for i, kp in enumerate(points):
                if min_f <= kp.co.x <= max_f:
                    indices_to_smooth.add(i)
            if len(indices_to_smooth) < 3 or len(indices_to_smooth) > 5:
                continue
            new_values = {}
            for i in indices_to_smooth:
                if i == 0 or i == len(points) - 1:
                    continue
                prev_y = points[i - 1].co.y
                curr_y = points[i].co.y
                next_y = points[i + 1].co.y
                avg = (prev_y + curr_y + next_y) / 3.0
                new_y = curr_y * (1 - strength) + avg * strength
                new_values[i] = new_y
            for i, val in new_values.items():
                points[i].co.y = val
        fcurve.update()

    smooth_curve(fcurve_z, framesScope, strength=0.7)
    smooth_curve(fcurve_y, framesScope, strength=0.7)
    smooth_curve(fcurve_x, framesScope, strength=0.7)

    return True
