# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "ADDON_NAME",
    "author": "AUTHOR_NAME",
    "description": "",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Generic",
}


#def register(): ...


#def unregister(): ...
import bpy

from .UI import *
from .Footplant import *

# ------------------------
# REGISTER
# ------------------------
classes = (
    BoneItem,
    ScopeItem,
    MySettings,
    BONE_UL_List,
    SCOPE_UL_List,
    LoadTargetBonesOperator,
    RunOperator,
    MyPanel,
    AddScopeOperator,
    AddScopeLeftOperator,
    AddScopeRightOperator,
    RemoveScopeOperator,
    RemoveScopeLeftOperator,
    RemoveScopeRightOperator,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.my_settings = bpy.props.PointerProperty(type=MySettings)

    #bpy.ops.object.run_operator()
    # register depsgraph handler to auto-update bone name strings on index change



def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    # remove handler if present


    del bpy.types.Scene.my_settings


if __name__ == "__main__":
    register()
