import bpy
import sys, traceback
print(sys.path)
try:
    # When running as a text/script in Blender the plain import usually works
    from Footplant import apply_footplant
except Exception:
    try:
        # When the module is a package or different import context
        from .Footplant import apply_footplant
    except Exception:
        apply_footplant = None




def update_target_left(self, context):
    if 0 <= self.target_index_left_foot < len(self.target_bones):
        self.target_left_bone = self.target_bones[self.target_index_left_foot].name
    else:
        self.target_left_bone = ""

def update_target_right(self, context):
    if 0 <= self.target_index_right_foot < len(self.target_bones):
        self.target_right_bone = self.target_bones[self.target_index_right_foot].name
    else:
        self.target_right_bone = ""

def update_target_left_toe_base (self, context):
    if 0 <= self.target_index_left_toe_base < len(self.target_bones):
        self.target_left_toe_base = self.target_bones[self.target_index_left_toe_base].name
    else:
        self.target_left_toe_base = ""

def update_target_right_toe_base (self, context):
    if 0 <= self.target_index_right_toe_base < len(self.target_bones):
        self.target_right_toe_base = self.target_bones[self.target_index_right_toe_base].name
    else:
        self.target_right_toe_base = ""

class BoneItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()



class ScopeItem(bpy.types.PropertyGroup):
    start: bpy.props.IntProperty(name="Start", default=1, min=1)
    end: bpy.props.IntProperty(name="End", default=1, min=1)

class MySettings(bpy.types.PropertyGroup):
    Target_Rig: bpy.props.PointerProperty(type=bpy.types.Object, poll=lambda self, obj: obj.type == 'ARMATURE')

    target_bones: bpy.props.CollectionProperty(type=BoneItem)

    target_index_left_foot: bpy.props.IntProperty(update=update_target_left)
    target_index_right_foot: bpy.props.IntProperty(update=update_target_right)

    target_index_left_toe_base : bpy.props.IntProperty(update=update_target_left_toe_base)
    target_index_right_toe_base : bpy.props.IntProperty(update=update_target_right_toe_base)

    target_left_bone: bpy.props.StringProperty(name="Target Left Bone")
    target_right_bone: bpy.props.StringProperty(name="Target Right Bone")
    target_right_toe_base : bpy.props.StringProperty(name="Target Right Toe Base") # ! neu
    target_left_toe_base: bpy.props.StringProperty(name="Target Left Toe Base")

    # UI list toggles
    show_target_left_list: bpy.props.BoolProperty(name="Show Target Left Foot List", default=False)
    show_target_right_list: bpy.props.BoolProperty(name="Show Target Right Foot List", default=False)
    show_target_left_toe_base_list : bpy.props.BoolProperty(name="Show Target Left Toe Base List", default=False) #! neu
    show_target_right_toe_base_list : bpy.props.BoolProperty(name="Show Target Right Toe Base List", default=False)

    # z_threshold removed per user request
    # Freeze option (only Z)
    freeze_x: bpy.props.BoolProperty(name="Freeze X", default=False)
    freeze_y: bpy.props.BoolProperty(name="Freeze Y", default=False)
    freeze_z: bpy.props.BoolProperty(name="Freeze Z", default=True)

    # Scopes for manual frames (list of ranges)
    scopes_add: bpy.props.CollectionProperty(type=ScopeItem)
    scopes_add_index: bpy.props.IntProperty(default=0)
    scopes_left: bpy.props.CollectionProperty(type=ScopeItem)
    scopes_left_index: bpy.props.IntProperty(default=0)
    scopes_right: bpy.props.CollectionProperty(type=ScopeItem)
    scopes_right_index: bpy.props.IntProperty(default=0)

    # Toe correction mode: relative (False) or absolute (True)
    absolute_toe_correction: bpy.props.BoolProperty(name="Foot Roll Correction", default=False)




# ------------------------
# UI LIST
# ------------------------
class BONE_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.label(text=item.name)



class SCOPE_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        # Split the row so we have start/end on the left and a fixed X button on the right
        split = layout.split(factor=0.95)
        left = split.row(align=True)
        right = split.row(align=True)

        left.prop(item, "start", text="Start")
        left.prop(item, "end", text="End")

        # operator to remove this specific index; operator must accept 'index'
        op = right.operator("object.remove_scope", text="", icon='X')
        try:
            op.index = data.scopes_add_index
        except Exception:
            op.index = 0



# ------------------------
# Load Target Bones
# ------------------------
class LoadTargetBonesOperator(bpy.types.Operator):
    bl_idname = "object.load_target_bones"
    bl_label = "Load Target Bones"

    def execute(self, context):
        settings = context.scene.my_settings
        settings.target_bones.clear()

        obj = settings.Target_Rig

        if obj and obj.type == 'ARMATURE':
            for bone in obj.data.bones:
                item = settings.target_bones.add()
                item.name = bone.name

        return {'FINISHED'}


# Scope list operators
class AddScopeOperator(bpy.types.Operator):
    bl_idname = "object.add_scope"
    bl_label = "Add Scope"

    def execute(self, context):
        settings = context.scene.my_settings
        item = settings.scopes_add.add()
        item.start = 1
        item.end = 1
        settings.scopes_add_index = len(settings.scopes_add) - 1
        return {'FINISHED'}


class AddScopeLeftOperator(bpy.types.Operator):
    bl_idname = "object.add_scope_left"
    bl_label = "Add Interval Left"

    def execute(self, context):
        settings = context.scene.my_settings
        item = settings.scopes_left.add()
        item.start = 1
        item.end = 1
        settings.scopes_left_index = len(settings.scopes_left) - 1
        return {'FINISHED'}


class AddScopeRightOperator(bpy.types.Operator):
    bl_idname = "object.add_scope_right"
    bl_label = "Add Interval Right"

    def execute(self, context):
        settings = context.scene.my_settings
        item = settings.scopes_right.add()
        item.start = 1
        item.end = 1
        settings.scopes_right_index = len(settings.scopes_right) - 1
        return {'FINISHED'}


class RemoveScopeOperator(bpy.types.Operator):
    bl_idname = "object.remove_scope"
    bl_label = "Remove Scope"
    index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        settings = context.scene.my_settings
        # default: remove from global scopes_add
        idx = self.index if (0 <= self.index < len(settings.scopes_add)) else settings.scopes_add_index
        if 0 <= idx < len(settings.scopes_add):
            settings.scopes_add.remove(idx)
            settings.scopes_add_index = max(0, idx - 1)
        return {'FINISHED'}


class RemoveScopeLeftOperator(bpy.types.Operator):
    bl_idname = "object.remove_scope_left"
    bl_label = "Remove Scope Left"
    index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        settings = context.scene.my_settings
        idx = self.index if (0 <= self.index < len(settings.scopes_left)) else settings.scopes_left_index
        if 0 <= idx < len(settings.scopes_left):
            settings.scopes_left.remove(idx)
            settings.scopes_left_index = max(0, idx - 1)
        return {'FINISHED'}


class RemoveScopeRightOperator(bpy.types.Operator):
    bl_idname = "object.remove_scope_right"
    bl_label = "Remove Scope Right"
    index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        settings = context.scene.my_settings
        idx = self.index if (0 <= self.index < len(settings.scopes_right)) else settings.scopes_right_index
        if 0 <= idx < len(settings.scopes_right):
            settings.scopes_right.remove(idx)
            settings.scopes_right_index = max(0, idx - 1)
        return {'FINISHED'}



# (Set bone operators removed — selection is handled automatically by the index watcher)





# ------------------------
# MAIN OPERATOR
# ------------------------
class RunOperator(bpy.types.Operator):
    bl_label = "Run Foot Plant"
    bl_idname = "object.run_operator"

    def execute(self, context):
        settings = context.scene.my_settings

        if not settings.target_left_bone:
            print ("Bone not set")
            return {'CANCELLED'}
        if not settings.target_right_bone:
            print ("Bone not set")
            return {'CANCELLED'}
        # Call the footplant function if available
        if apply_footplant is None:
            print("apply_footplant not found (import failed)")
            return {'CANCELLED'}

        print("Test")
        tgt_name = settings.Target_Rig.name if settings.Target_Rig else ""

        try:
            # left foot
            print("Left Foot")
            left_scopes = [(s.start, s.end) for s in settings.scopes_left]
            apply_footplant(
                obj_target_name=tgt_name,
                bone_target_name=settings.target_left_bone,
                target_toe_base=settings.target_left_toe_base,
                absolute_toe_correction=settings.absolute_toe_correction,
                scopes=left_scopes,
            )
            # right foot
            print("Right Foot")
            right_scopes = [(s.start, s.end) for s in settings.scopes_right]
            apply_footplant(
                obj_target_name=tgt_name,
                bone_target_name=settings.target_right_bone,
                target_toe_base=settings.target_right_toe_base,
                absolute_toe_correction=settings.absolute_toe_correction,
                scopes=right_scopes,
            )
        except Exception as e:
            print(f"Fehler beim Aufruf von apply_footplant: {e}")
            return {'CANCELLED'}

        print("FINISHED")
        return {'FINISHED'}



# ------------------------
# PANEL
# ------------------------
class MyPanel(bpy.types.Panel):
    bl_label = "Foot Plant"
    bl_idname = "OBJECT_PT_footPlant"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Foot Plant"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.my_settings
        layout.operator("object.run_operator", icon="PLAY")
        layout.prop(settings, "z_threshold")
        row = layout.row(align=True)
        row.prop(settings, "freeze_x")
        row.prop(settings, "freeze_y")
        row.prop(settings, "freeze_z")
        layout.prop(settings, "absolute_toe_correction")
        layout.separator()

        # TARGET
        layout.separator()
        layout.separator()
        layout.separator()

        layout.prop(settings, "Target_Rig")
        layout.operator("object.load_target_bones")

        layout.separator()
        layout.label(text="Left Foot Interval")
        col_left_scopes = layout.column()
        for i, scope in enumerate(settings.scopes_left):
            main_row = col_left_scopes.row()
            split = main_row.split(factor=0.95)
            left = split.row()
            right = split.row()

            col_group = left.column(align=True)
            row1 = col_group.row(align=True)
            row1.prop(scope, "start", text="Start")
            row1.prop(scope, "end", text="End")

            right.alignment = 'RIGHT'
            right.operator("object.remove_scope_left", text="", icon='X').index = i

            col_left_scopes.separator()

        layout.operator("object.add_scope_left", icon='ADD')

        layout.separator()
        layout.label(text="Right Foot Interval")
        col_right_scopes = layout.column()
        for i, scope in enumerate(settings.scopes_right):
            main_row = col_right_scopes.row()
            split = main_row.split(factor=0.95)
            left = split.row()
            right = split.row()

            col_group = left.column(align=True)
            row1 = col_group.row(align=True)
            row1.prop(scope, "start", text="Start")
            row1.prop(scope, "end", text="End")

            right.alignment = 'RIGHT'
            right.operator("object.remove_scope_right", text="", icon='X').index = i

            col_right_scopes.separator()

        layout.operator("object.add_scope_right", icon='ADD')


        # Target bone selectors (use prop_search when armature set)
        row = layout.row(align=True)
        if settings.Target_Rig and settings.Target_Rig.type == 'ARMATURE':
            row.prop_search(settings, "target_left_bone", settings.Target_Rig.data, "bones", text="Left IK Bone")
        else:
            row.prop(settings, "target_left_bone", text="Left IK Bone")

        row2 = layout.row(align=True)
        if settings.Target_Rig and settings.Target_Rig.type == 'ARMATURE':
            row2.prop_search(settings, "target_right_bone", settings.Target_Rig.data, "bones", text="Right IK Bone")
        else:
            row2.prop(settings, "target_right_bone", text="Right IK Bone")


        # Replace toe-base lists with prop_search fields that search the armature bones
        row = layout.row(align=True)
        if settings.Target_Rig and settings.Target_Rig.type == 'ARMATURE':
            row.prop_search(settings, "target_right_toe_base", settings.Target_Rig.data, "bones", text="Right Toe Base")
        else:
            row.prop(settings, "target_right_toe_base", text="Right Toe Base")

        row2 = layout.row(align=True)
        if settings.Target_Rig and settings.Target_Rig.type == 'ARMATURE':
            row2.prop_search(settings, "target_left_toe_base", settings.Target_Rig.data, "bones", text="Left Toe Base")
        else:
            row2.prop(settings, "target_left_toe_base", text="Left Toe Base")