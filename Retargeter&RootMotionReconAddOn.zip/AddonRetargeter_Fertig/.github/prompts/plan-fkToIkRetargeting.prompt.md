## Plan: FK zu IK Retargeting erweitern

Der Retargeter bleibt FK→FK-kompatibel und wird um einen pro-Chain Modus erweitert, sodass einzelne Chains FK oder IK nutzen. IK-Ziel ist zuerst auf 2-Bone-Ketten (Arme, Beine) fokussiert, Pole wird automatisch aus der Source-Mittelkette abgeleitet, und Root Motion bleibt wie bisher auf Objekt-Ebene erhalten.

**Steps**

1. Phase 1: Datenmodell und Modus-Schaltung einführen.
2. In `Chain` neue Properties ergänzen: `retarget_mode` (Enum: FK, IK), `ik_target_bone` (String), optional `ik_hint_source_mid` (String/Auto-Flag). _Blockiert alle Folgeschritte._
3. In `Armature` eine optionale globale Default-Strategie ergänzen (z. B. `default_retarget_mode`) nur als UX-Default, nicht als Laufzeitzwang. _Parallel mit Schritt 2 möglich._
4. Migrations-/Fallback-Verhalten definieren: Bestehende Chains ohne neue Werte laufen weiterhin als FK. _depends on 2._
5. Phase 2: UI pro Chain für FK/IK erweitern.
6. In Panel-Draw pro Chain einen Modus-Selector anzeigen; bei FK bleibt die bestehende Start/End + Target Start/End Eingabe sichtbar. _depends on 2._
7. Bei IK-Modus UI für IK-Zielknochen (Target-Control/End-Controller) anzeigen sowie Hinweis „Pole automatisch aus Source-Mittelknochen“. _depends on 2._
8. Validierungsfeedback im UI verbessern (z. B. fehlender IK-Target-Bone, inkonsistente Kette) statt erst beim Execute-Fehler. _parallel mit 6 möglich._
9. Phase 3: Operator-Pipeline auf FK/IK dispatch umbauen.
10. `CalculateRetargeting.execute` in zwei Pfade aufteilen: FK-Pfad (bestehend) und IK-Pfad (neu), jeweils pro Chain anhand `retarget_mode`. _depends on 2, 6._
11. Für IK-Chains dedizierte Validierung einbauen: Source-Kette vorhanden, mindestens 2 Bones, IK-Target-Bone vorhanden, Target-Armature gültig. _depends on 10._
12. Bestehenden FK-Flow unverändert lassen (`get_chain`, `retarget_animation`, `apply_offset_to_fcurves_copy`) und nur über Dispatcher aufrufen, um Regressionen zu minimieren. _depends on 10._
13. Phase 4: IK-Berechnungsweg implementierungsreif designen.
14. Neue IK-Funktionsfamilie definieren (separate Funktionen statt FK-Funktionen zu überladen):
15. `retarget_animation_ik(...)` als Orchestrator für IK-Chains.
16. `extract_source_effector_trajectory(...)` zur Ermittlung der Source-Endeffektor-Bewegung über Frames.
17. `compute_auto_pole_trajectory(...)` aus Source-Mittelknochen (Arme/Beine 2-Bone: Joint-basierter Pole-Vektor).
18. `apply_ik_target_fcurves(...)` zum Schreiben der IK-Control-Bone-Locations (und optional Rotation je Rig-Bedarf).
19. Transformationsraum festlegen: zuerst Armature-Space konsistent mit bestehender Restpose-Logik; beim Schreiben in IK-Controller auf den vom Controller erwarteten Space mappen. _depends on 10._
20. Skalierung wiederverwenden: Längen-/Root-Scaling aus vorhandenen Hilfsfunktionen integrieren, damit FK und IK gleiche Größenlogik haben. _depends on 16._
21. Phase 5: IK-Bone/Constraint-Handling robust machen.
22. Vor dem Schreiben prüfen, ob Target-Rig für IK bereit ist (IK-Control-Bone vorhanden, optional IK-Constraint auf Deform-Chain vorhanden). _depends on 11._
23. Entscheidung: Add-on erzeugt Constraints nicht automatisch, sondern validiert und meldet präzise, was im Rig fehlt; optional später „Auto-Setup“ als separater Operator. _depends on 22._
24. Für Arme/Beine eigene Preset-Validierungen vorsehen (z. B. erwartete 2-Bone-Topologie), um frühe, verständliche Fehler zu liefern. _parallel mit 22 möglich._
25. Phase 6: Verifikation und Absicherung.
26. Regressionstests FK: bestehende FK→FK-Beispiele unverändert vergleichen (Keyframe-Anzahl, Bewegungsverlauf, Quaternion-Kontinuität). _depends on 10._
27. IK-Funktionstests Arme/Beine: Endeffektor folgt Source-Trajektorie, Pole stabil, kein Pop/Flip bei schnellen Richtungswechseln. _depends on 14._
28. Mixed-Mode-Test: Szene mit FK- und IK-Chains gleichzeitig in einem Durchlauf.
29. Blender-5-Action-Layer-Fälle explizit testen (Action Slot vorhanden/nicht vorhanden), damit IK-Schreibpfad dieselbe Robustheit wie FK hat.

**Relevant files**

- `s:/BlenderScripts/Bachelor/AddonRetargeter/retargering.py` — zentrale Änderungen: PropertyGroups (`Chain`, `Armature`), UI (`MyPanel.draw`), Dispatcher (`CalculateRetargeting.execute`), neue IK-Orchestrierungs-/Berechnungsfunktionen neben bestehendem FK-Flow.
- `s:/BlenderScripts/Bachelor/AddonRetargeter/__init__.py` — falls Klassenregistrierung/Property-Anbindung hier geführt wird: neue Properties/Operatoren sicher registrieren.
- `s:/BlenderScripts/Bachelor/AddonRetargeter/auto_load.py` — prüfen, ob neue Klassen/Operatoren im Auto-Register berücksichtigt werden müssen.

**Verification**

1. Blender manuell: 1 FK-Chain (bestehend) retargeten und Ergebnis gegen aktuellen Stand vergleichen.
2. Blender manuell: 1 Arm-IK-Chain retargeten, IK-Control-Bone-Trajektorie und Gelenkbeugung prüfen.
3. Blender manuell: 1 Bein-IK-Chain retargeten inkl. schneller Bewegungen, Pole-Stabilität beobachten.
4. Mixed-Test: eine Szene mit mindestens einer FK- und einer IK-Chain in einem Lauf, auf Fehlerreports und Keyframe-Schreibpfade prüfen.
5. Edge-Test: fehlender IK-Target-Bone, falsche Chain-Länge, fehlender Constraint — jeweils klare Fehlermeldung ohne Add-on-Absturz.
6. Action-API-Test: Blender-5-Layered-Action/Slot-Fälle durchspielen, sicherstellen, dass FCurves für IK korrekt erzeugt/gefunden werden.

**Decisions**

- Pro-Chain Modus ist gesetzt (FK und IK gemischt pro Lauf erlaubt).
- Erste IK-Zielgruppe ist 2-Bone IK für Arme und Beine; Spine/General-IK explizit out of scope für den ersten Schritt.
- Pole wird automatisch aus dem Source-Mittelknochen abgeleitet.
- Root Motion bleibt auf Objekt-Ebene wie im bestehenden FK-Flow.
- IK-Control-Bone und Constraint-Setup wird validiert, aber initial nicht automatisch erzeugt.

**Further Considerations**

1. Empfehlung für Iteration 2: optionaler Operator „IK Auto-Setup“ (Constraint + Pole-Bone-Zuweisung) für standardisierte Rigs.
2. Empfehlung für Iteration 2: per-Chain Space-Option (World/Local/Custom) falls unterschiedliche Controller-Rigs unterstützt werden sollen.
3. Empfehlung für Iteration 2: sanftere n:m-Mappings (Slerp/Lerp zwischen benachbarten Source-Bones) auch für FK weiter ausbauen.
