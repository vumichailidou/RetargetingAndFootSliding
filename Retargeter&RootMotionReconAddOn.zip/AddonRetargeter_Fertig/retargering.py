import bpy
import bpy_extras
import math
from mathutils import Quaternion, Vector, Euler

"""Retargeting- und Root-Motion-Werkzeuge fuer Blender.

Mathematisches Modell (Kurzueberblick):
- Ein Bone hat lokale Rotation/Translation relativ zum Parent.
- Quaternions werden zur stabilen Rotationsuebertragung genutzt.
- Restpose dient als Referenz, damit Source- und Target-Rig mit
  unterschiedlicher Bone-Ausrichtung korrekt gemappt werden.

Wichtige Formeln:
1) Lokale Translation auf Ziel-Bone-Basis drehen:
    v_tgt = q_tgt_rest^{-1} * (q_src_rest * v_src)

2) Laengenskalierung pro Bone:
    s = ||bone_tgt|| / ||bone_src||
    v_src_scaled = s * v_src

3) Root-Motion-Skalierung (root->spine Distanz):
    s_root = d_tgt(root, spine) / d_src(root, spine)

4) Kontakt-Score fuer Stuetzfusswahl:
    score = |z - z_min| + w_speed * ||Delta_xy||

5) Rotationsmapping mit Restpose-Korrektur (schematisch):
    q_convert = q_src_rest_world^{-1} * q_tgt_rest_world
    q_tgt_pose_world = q_src_pose_world * q_convert
    q_tgt_local_delta = q_tgt_rest_local^{-1} * q_tgt_local_abs

Notation:
- q_a * q_b ist Quaternion-Komposition (zuerst q_b, dann q_a auf Vektorraum).
- @ zwischen Matrix/Quaternion und Vektor entspricht Blender-Transformation.
"""



class Chain(bpy.types.PropertyGroup):
    """Ein einzelnes Segment einer Bone-Chain (Start- und End-Bone-Name)."""

    chain_start: bpy.props.StringProperty(name="Start Bone")
    chain_end: bpy.props.StringProperty(name="End Bone")




def get_chain(chain_start,chain_end):
    """Liest Parent-Links von `chain_end` bis `chain_start` aus.

    Rueckgabe:
    - Liste in Top-Down-Reihenfolge (start -> end), falls gueltig.
    - Nur ein Eintrag in Liste, falls `chain_start` kein Vorfahr von `chain_end` ist.
    """
    bones = []
    current = chain_end

    while current:
        bones.append(current)
        if current == chain_start:
            break
        current = current.parent
        if current is None:
            break

    if not bones or bones[-1] != chain_start:
        return []
    bones.reverse()  # von start → end
    return bones

class Armature(bpy.types.PropertyGroup):
    """Global addon settings for source/target and root motion."""
    armature : bpy.props.PointerProperty(type=bpy.types.Object, poll=lambda self, obj: obj.type == 'ARMATURE')
    chains : bpy.props.CollectionProperty(type=Chain)

    armature_target : bpy.props.PointerProperty(type=bpy.types.Object, poll=lambda self, obj: obj.type == 'ARMATURE')
    chains_target : bpy.props.CollectionProperty(type=Chain)
    root_motion_armature : bpy.props.PointerProperty(
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'ARMATURE'
    )

    root_master_bone: bpy.props.StringProperty(
        name="Root Bone",
        description="Bone that receives the root motion",
        default="root",
    )
    root_lock_bone_left: bpy.props.StringProperty(
        name="Left Foot",
        description="Left foot bone for root motion (Biped)",
        default="",
    )
    root_lock_bone_right: bpy.props.StringProperty(
        name="Right Foot",
        description="Right foot bone for root motion (Biped)",
        default="",
    )
    root_lock_type: bpy.props.EnumProperty(
        name="Lock Type",
        description="Which point of the lock bones is fixed",
        items=[
            ('HEAD', 'HEAD', 'Fixes the head point of the lock bones'),
            ('TAIL', 'TAIL', 'Fixes the end point of the lock bones'),
            ('CENTER', 'CENTER', 'Fixes the center point of the lock bones'),
        ],
        default='HEAD',
    )
    root_contact_tolerance: bpy.props.FloatProperty(
        name="Global Z Threshold",
        description="Tolerance above the minimum Z height for ground contact",
        default=0.5,
        min=0.0,
        soft_max=1.0,
    )

    source_root : bpy.props.StringProperty(name="Source Root Bone", default="")
    target_root: bpy.props.StringProperty(name="Target Root Bone", default="")
    scale_enum : bpy.props.EnumProperty(name = "location scale method", items = [('BONE', 'Bone Scale', 'Scales based on individual bone lengths'),
                                               ('CHAIN', 'Chain Scale', 'Scales according to the total chain length'),('COMBINE', 'Combine', 'Scales based on a combination of bone and chain scales (geometric mean)')],
                                               default='CHAIN')


class AddOperator (bpy.types.Operator):
    """Add a new source/target chain pair."""
    bl_idname = "object.add_operator"
    bl_label = "Add Chain"


    def execute(self, context):
        armature = context.scene.armature
        armature.chains.add()
        armature.chains_target.add()
        return {'FINISHED'}


class RemoveChainOperator(bpy.types.Operator):
    """Remove a source/target chain pair by its index."""
    bl_idname = "object.remove_chain_operator"
    bl_label = "Remove Chain Operator"

    index: bpy.props.IntProperty()

    def execute(self, context):
        armature = context.scene.armature

        if 0 <= self.index < len(armature.chains):
            armature.chains.remove(self.index)
            armature.chains_target.remove(self.index)
        return {'FINISHED'}


class BoneChains:
    """Container for validated source/target bone pairs for each chain."""
    def __init__(self, start, end, target_start, target_end):
        self.start = start
        self.end = end
        self.target_start = target_start
        self.target_end = target_end

class CalculateRetargeting(bpy.types.Operator):
    """Validates all defined chains and starts the retargeting process."""
    bl_idname = "object.calculate_retargeting"
    bl_label = "Calculate Retargeting"

    def execute(self, context):

        armature = context.scene.armature
        if armature.armature and armature.armature.type == 'ARMATURE':
            bone_chains = []
            for i, chain in enumerate(armature.chains):
                source_start_bone = armature.armature.pose.bones.get(chain.chain_start)
                source_end_bone = armature.armature.pose.bones.get(chain.chain_end)
                target_start_bone = armature.armature_target.pose.bones.get(armature.chains_target[i].chain_start)
                target_end_bone = armature.armature_target.pose.bones.get(armature.chains_target[i].chain_end)

                if source_start_bone is not None and source_end_bone is not None and target_start_bone is not None and target_end_bone is not None:
                    bone_chains.append(BoneChains(source_start_bone, source_end_bone, target_start_bone, target_end_bone))
                else:
                    self.report({'ERROR'}, f"Invalid bone chain at index {i}")
                    return {"CANCELLED"}

            for chain in bone_chains:
                chain_a = get_chain(chain.start, chain.end)
                chain_b = get_chain(chain.target_start, chain.target_end)
                if not chain_a:
                    self.report({'ERROR'}, f"Invalid bone chain {chain.start.name} to {chain.end.name}")
                    return {"CANCELLED"}
                if not chain_b:
                    self.report({'ERROR'}, f"Invalid bone chain {chain.target_start.name} to {chain.target_end.name}")
                    return {"CANCELLED"}

                retarget_animation(source_armature = armature.armature, target_armature = armature.armature_target, chain_source=chain_a, chain_target=chain_b, source_root=armature.source_root, target_root=armature.target_root, scale_enum=armature.scale_enum)
        return {'FINISHED'}


def _resolve_root_motion_armature(settings):
    """Waehlt das Rig fuer Root-Motion in Prioritaetsreihenfolge. Hast Mehrere Auswahl bis jetzt.
    Sollte man aber vielleicht entfernen zur klarbeiheit

    Reihenfolge:
    1) explizit gesetztes Root-Rig
    2) Target-Rig
    3) Source-Rig
    """
    if settings.root_motion_armature and settings.root_motion_armature.type == 'ARMATURE':
        return settings.root_motion_armature
    if settings.armature_target and settings.armature_target.type == 'ARMATURE':
        return settings.armature_target
    if settings.armature and settings.armature.type == 'ARMATURE':
        return settings.armature
    return None


# Lock-Bone sind in meinem Fall die Füße
def _lock_point_world(armature_obj, lock_bone, lock_type):
    """Gibt den ausgewaehlten Lock-Punkt eines Bones in Weltkoordinaten zurueck."""
    if lock_type == 'TAIL':
        return armature_obj.matrix_world @ lock_bone.tail
    if lock_type == 'CENTER':
        center = (lock_bone.head + lock_bone.tail) * 0.5
        return armature_obj.matrix_world @ center
    return armature_obj.matrix_world @ lock_bone.head # Head


def _collect_contact_intervals(frames, z_values, tolerance):
    """Detektiert Bodenkontaktintervalle aus Z-Hoehen.

    Kriterium:
    z(frame) <= z_min + tolerance

    Danach werden Kontaktframes zur Jitter-Daempfung um +/- 1 Frame erweitert
    und zu zusammenhaengenden Intervallen [start, end] gruppiert.
    """
    if not frames or not z_values:
        return []

    z_min = min(z_values)
    threshold = z_min + max(0.0, tolerance)
   # contact_frames = [frame for frame, z in zip(frames, z_values) if z <= threshold]
    contact_frames = []
    for frame, z in zip(frames, z_values):
        if z <= threshold:
            contact_frames.append(frame)

    if not contact_frames:
        return []

    # Stabilisiert Kontaktphasen bei leichtem Jitter:
    # erkannte Kontaktframes um +/-1 Frame erweitern.
    frame_min = frames[0]
    frame_max = frames[-1]
    expanded = set(contact_frames) # entfernd die duplicate
    for frame in contact_frames:
        if frame - 1 >= frame_min:
            expanded.add(frame - 1)
        if frame + 1 <= frame_max:
            expanded.add(frame + 1)
    contact_frames = sorted(expanded) # alle frames werden hinzugefügt und sortiert

    intervals = []
    start = contact_frames[0]
    prev = contact_frames[0]
    for frame in contact_frames[1:]: # Invervale finden
        if frame == prev + 1:
            prev = frame
            continue
        intervals.append((start, prev))
        start = frame
        prev = frame
    intervals.append((start, prev))
    return intervals


class ApplyRootMotionOperator(bpy.types.Operator):
   # Foot-Lock basierte Root-Motion-Translation fuer Biped-Rigs.

   # Idee:
   # - Kontaktphasen fuer linken/rechten Fuss erkennen.
   # - Aktiven Stuetzfuss waehlen.
   # - Dessen Weltpunkt waehrend Kontakt fixieren.
   # - Offset auf Master-Bone-Translation backen.

    bl_idname = "object.apply_root_motion"
    bl_label = "Apply Root Motion"

    def execute(self, context):
        settings = context.scene.armature

        rig = _resolve_root_motion_armature(settings)
        if rig is None:
            self.report({'ERROR'}, "Kein gueltiges Armature-Objekt gesetzt")
            return {'CANCELLED'}

        if not settings.root_master_bone.strip() or not settings.root_lock_bone_left.strip() or not settings.root_lock_bone_right.strip():
            self.report({'ERROR'}, "Master Bone und beide Lock-Bones muessen gesetzt sein")
            return {'CANCELLED'}

        master_bone = rig.pose.bones.get(settings.root_master_bone)
        if master_bone is None:
            self.report({'ERROR'}, f"Master Bone '{settings.root_master_bone}' nicht gefunden")
            return {'CANCELLED'}

        start_frame = int(context.scene.frame_start)
        end_frame = int(context.scene.frame_end)
        if end_frame < start_frame:
            self.report({'ERROR'}, "Invalid frame range: end_frame < start_frame.")
            return {'CANCELLED'}

        frames = list(range(start_frame, end_frame + 1))
        if not frames:
            self.report({'ERROR'}, "Empty frame range")
            return {'CANCELLED'}

        original_frame = context.scene.frame_current

        # Nur zwei Lock-Bones (Biped): linkes und rechtes Fuß-Bone
        left_name = settings.root_lock_bone_left.strip()
        right_name = settings.root_lock_bone_right.strip()
        if not left_name or not right_name:
            self.report({'ERROR'}, "Please set both foot bones: Left Foot and Right Foot")
            return {'CANCELLED'}

        left_bone = rig.pose.bones.get(left_name)
        right_bone = rig.pose.bones.get(right_name)
        missing = []
        if left_bone is None:
            missing.append(left_name)
        if right_bone is None:
            missing.append(right_name)
        if missing:
            self.report({'ERROR'}, f"Lock bones not found: {', '.join(missing)}")
            return {'CANCELLED'}

        # Samples: pro Bone eine Map frame->point; Root pro Frame.
        # Mathematisch: p_world(frame) als diskrete Zeitreihe.
        sampled_lock_points = {left_name: {}, right_name: {}}
        sampled_root_world = {}
        z_values_per_bone = {left_name: [], right_name: []}

        for frame in frames:
            context.scene.frame_set(frame)
            sampled_root_world[frame] = (rig.matrix_world @ master_bone.matrix).copy()
            pL = _lock_point_world(rig, left_bone, settings.root_lock_type)
            pR = _lock_point_world(rig, right_bone, settings.root_lock_type)
            sampled_lock_points[left_name][frame] = pL
            sampled_lock_points[right_name][frame] = pR
            z_values_per_bone[left_name].append(pL.z)
            z_values_per_bone[right_name].append(pR.z)

        # Pro Bone Offsets berechnen:
        # delta(frame) = lock_target - current_point, nur in XY (delta.z = 0).
        # Damit bleibt Fuss waehrend Kontakt planar fixiert.
        offsets_per_bone = {left_name: {frame: Vector((0.0, 0.0, 0.0)) for frame in frames},
                            right_name: {frame: Vector((0.0, 0.0, 0.0)) for frame in frames}}
        contact_frames_per_bone = {left_name: set(), right_name: set()}
        interval_count_total = 0

        any_intervals_found = False
        for name in (left_name, right_name):
            z_vals = z_values_per_bone[name]
            intervals = _collect_contact_intervals(frames, z_vals, settings.root_contact_tolerance)
            if not intervals:
                continue
            any_intervals_found = True
            interval_count_total += len(intervals)

            for i_start, i_end in intervals:
                contact_frames_per_bone[name].update(range(i_start, i_end + 1))

            #Fixiert den Fuß in XY während Kontakt und summiert die Korrektur, damit keine Positionssprünge entstehen.
            acc = Vector((0.0, 0.0, 0.0))
            cur = start_frame
            for istart, iend in intervals:
                for f in range(cur, istart):
                    if f in offsets_per_bone[name]:
                        offsets_per_bone[name][f] = acc.copy()

                lock_target = sampled_lock_points[name][istart].copy()
                last_delta = Vector((0.0, 0.0, 0.0))
                for f in range(istart, iend + 1):
                    current_point = sampled_lock_points[name][f]
                    delta = lock_target - current_point
                    delta.z = 0.0 # alle z werden hier gelockt
                    last_delta = delta.copy()
                    offsets_per_bone[name][f] = acc + delta

                acc += last_delta # ! verhindert sprünge !
                cur = iend + 1

            for f in range(cur, end_frame + 1):
                if f in offsets_per_bone[name]:
                    offsets_per_bone[name][f] = acc.copy() # !

        if not any_intervals_found:
            context.scene.frame_set(original_frame)
            self.report({'WARNING'}, "No ground contact intervals detected for the two lock bones")
            return {'CANCELLED'}

        z_min_per_bone = {
            left_name: min(z_values_per_bone[left_name]),
            right_name: min(z_values_per_bone[right_name]),
        }

        # Planare Fussgeschwindigkeit pro Frame (fuer robustere Stuetzwahl):
        # v_xy(frame) = || (p(frame) - p(frame-1))_xy ||
        foot_speed_per_bone = {
            left_name: {frame: 0.0 for frame in frames},
            right_name: {frame: 0.0 for frame in frames},
        }
        for name in (left_name, right_name):
            prev_point = None
            for frame in frames:
                point = sampled_lock_points[name][frame]
                if prev_point is None:
                    foot_speed_per_bone[name][frame] = 0.0
                else:
                    planar_delta = point - prev_point
                    planar_delta.z = 0.0  # ! Abstand einem Punkt zum vorherigen Punkt , und davon dann die Länge
                    foot_speed_per_bone[name][frame] = planar_delta.length # ! Geschwindigkeit pro Frame
                prev_point = point.copy()

        # Kontaktbasierte Kombination:
        # - aktiven Stuetzfuss waehlen
        # - dessen Weltpunkt waehrend Kontakt fixieren
        # - bei Stuetzwechsel Lockpunkt auf aktuelle Pose re-initialisieren
        # Score pro Fuss:
        # score = |z - z_min| + speed_weight * speed_xy
        offset_per_frame = {frame: Vector((0.0, 0.0, 0.0)) for frame in frames}
        last_offset = Vector((0.0, 0.0, 0.0))
        selected_support = None
        prev_support = None
        locked_support_point_world = None
        score_hysteresis = 0.002 # ! toleranz um ned sofort zu springen
        speed_weight = 0.5 # ! wie wichtig ist mir die gewindigkeit des Fußes, wichtig wenn beide füse auf den boden sind :/
        for frame in frames:
            left_contact = frame in contact_frames_per_bone[left_name]
            right_contact = frame in contact_frames_per_bone[right_name]

            zL = sampled_lock_points[left_name][frame].z
            zR = sampled_lock_points[right_name][frame].z
            speedL = foot_speed_per_bone[left_name][frame]
            speedR = foot_speed_per_bone[right_name][frame]
            scoreL = abs(zL - z_min_per_bone[left_name]) + (speed_weight * speedL) # ! Im Code wird bei gleichzeitigem Kontakt der Fuß mit dem kleineren score als aktiver Stuetzfuß gewählt.
            scoreR = abs(zR - z_min_per_bone[right_name]) + (speed_weight * speedR) # ! erst die abstand, dann Speed miteinberechnet, schneller (schlechter also höherer score)

            active_support = None

            if left_contact and right_contact:
                # Bei gleichzeitigem Kontakt mit Hysterese arbeiten,
                # damit die Stuetzseite bei ueberkreuzten Schritten stabil bleibt.
                if selected_support == left_name and scoreL <= (scoreR + score_hysteresis):
                    active_support = left_name
                elif selected_support == right_name and scoreR <= (scoreL + score_hysteresis):
                    active_support = right_name
                elif scoreL < scoreR:
                    active_support = left_name
                elif scoreR < scoreL:
                    active_support = right_name
                else:
                    active_support = selected_support
            elif left_contact:
                active_support = left_name
            elif right_contact:
                active_support = right_name
            else:
                active_support = None

            if active_support is None:
                combined = last_offset.copy()
                locked_support_point_world = None
            else:
                current_point = sampled_lock_points[active_support][frame]
                if active_support != prev_support or locked_support_point_world is None:
                    # Lockpunkt auf die aktuell erreichte (bereits offsetete) Position setzen.
                    locked_support_point_world = current_point + last_offset
                # Gesuchter Root-Offset, damit aktueller Fuss wieder auf den
                # gesperrten Weltpunkt faellt: delta = p_lock - p_current.
                delta = locked_support_point_world - current_point
                delta.z = 0.0
                combined = delta

            selected_support = active_support
            prev_support = active_support

            offset_per_frame[frame] = combined
            last_offset = combined.copy()

        for frame in frames:
            context.scene.frame_set(frame)

            # Root-Matrix in Weltkoordinaten um Translation versetzen und
            # zurueck in Rig-Lokalraum schreiben.
            root_world = sampled_root_world[frame].copy()
            root_world.translation = root_world.translation + offset_per_frame[frame]
            master_bone.matrix = rig.matrix_world.inverted() @ root_world
            master_bone.keyframe_insert(data_path="location", frame=frame)

        context.scene.frame_set(original_frame)
        self.report({'INFO'}, f"Root Motion Translation applied ({interval_count_total} contact intervals)")
        return {'FINISHED'}



class MyPanel (bpy.types.Panel):
    """UI-Panel fuer Chain-Definition und Start des Retargetings."""
    bl_label = "My FK Retargeter"
    bl_idname = "OBJECT_PT_my_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'My FK Retargeter'


    def draw (self, context):
        layout = self.layout
        armature = context.scene.armature
        layout.label(text="Armature:")
        layout.prop(armature, "armature", text="Source")
        layout.prop(armature, "armature_target", text="Target")

        layout.separator()
        layout.label(text="Chains:")
        if armature.armature and armature.armature.type == 'ARMATURE':
            for i, chain in enumerate(armature.chains):

                main_row = layout.row()

                split = main_row.split(factor=0.95)
                left = split.row(align=True)
                right = split.row(align=True)

                # -------------------------
                # LEFT SIDE (2 rows)
                # -------------------------
                col_left = left.column(align=True)

                row1 = col_left.row(align=True)
                row1.prop_search(chain, "chain_start", armature.armature.data, "bones", text="Src Start")
                row1.prop_search(chain, "chain_end", armature.armature.data, "bones", text="Src End")

                # -------------------------
                # TARGET (unter Start/End)
                # -------------------------
                row2 = col_left.row(align=True)
                if armature.armature_target and armature.armature_target.type == 'ARMATURE':
                    row2 = col_left.row(align=True)
                    row2.prop_search(
                        armature.chains_target[i],
                        "chain_start",
                        armature.armature_target.data,
                        "bones",
                        text="Tgt Start"
                    )

                    row2.prop_search(
                        armature.chains_target[i],
                        "chain_end",
                        armature.armature_target.data,
                        "bones",
                        text="Tgt End"
                    )
                else:
                    row2.label(text="No Target Armature", icon='ERROR')

                # -------------------------
                # RIGHT SIDE (X BUTTON FIXED WIDTH)
                # -------------------------
                right.alignment = 'RIGHT'
                right.operator(
                    "object.remove_chain_operator",
                    text="",
                    icon='X'
                ).index = i

                layout.separator()

            layout.separator()
            layout.label(text = "Root:")
            layout.prop_search(armature, "source_root", armature.armature.data, "bones", text="Source Root")
            layout.prop_search(armature, "target_root", armature.armature_target.data, "bones", text="Target Root")
            layout.prop(armature, "scale_enum", text="Location Scale Method")
            layout.operator("object.add_operator")
            layout.operator("object.calculate_retargeting",  icon='PLAY')


class RootMotionPanel(bpy.types.Panel):
    """UI-Panel fuer Foot-Lock-Root-Motion-Einstellungen."""
    bl_label = "Root Motion Recalculator"
    bl_idname = "OBJECT_PT_root_motion_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'My FK Retargeter'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.armature
        layout.prop(settings, "root_motion_armature", text="Armature")
        rig = _resolve_root_motion_armature(settings)


        col = layout.column(align=True)
        col.enabled = True

        if rig and rig.type == 'ARMATURE':
            col.prop_search(settings, "root_master_bone", rig.data, "bones", text="Root Bone")
            row = col.row(align=True)
            row.prop_search(settings, "root_lock_bone_left", rig.data, "bones", text="Left Foot")
            row.prop_search(settings, "root_lock_bone_right", rig.data, "bones", text="Right Foot")
        else:
            col.label(text="Setze Source oder Target Armature", icon='ERROR')

        col.prop(settings, "root_lock_type", text="Bone Type")
        col.prop(settings, "root_contact_tolerance")
        col.separator()
        col.operator("object.apply_root_motion", text="Start Root Calculator", icon='PLAY')





def get_fcurve(armature, data_path, index):
    """Sucht eine FCurve (Layered Actions + Legacy-Fallback)."""
    if armature.animation_data is None:
        armature.animation_data_create()

    animation_data = armature.animation_data
    if animation_data.action is None:
        animation_data.action = bpy.data.actions.new(name=f"{armature.name}_Action")

    action = animation_data.action

    if hasattr(action, "layers") and action.layers:
        for layer in action.layers:
            for strip in layer.strips:
                for channel in strip.channelbags:
                    for fc in channel.fcurves:
                        if fc.data_path == data_path and fc.array_index == index:
                            return fc
        return None

    if hasattr(action, "fcurves"):
        for fc in action.fcurves:
            if fc.data_path == data_path and fc.array_index == index:
                return fc

    return None


def ensure_action_and_slot(armature):
    """Stellt Animation Action und (wenn noetig) Action-Slot sicher."""
    if armature.animation_data is None:
        armature.animation_data_create()

    anim_data = armature.animation_data
    if anim_data.action is None:
        anim_data.action = bpy.data.actions.new(name=f"{armature.name}_Action")

    action = anim_data.action
    slot = getattr(anim_data, "action_slot", None)
    if slot is not None:
        return action, slot

    # Blender 5: vorhandenen Slot verwenden oder wenn moeglich erzeugen.
    slots = getattr(action, "slots", None)
    if slots is not None:
        try:
            if len(slots) > 0:
                anim_data.action_slot = slots[0]
                return action, anim_data.action_slot
        except Exception:
            pass

        create_attempts = [
            lambda: slots.new(armature.id_type, armature.name),
            lambda: slots.new(id_type=armature.id_type, name=armature.name),
            lambda: slots.new(armature.name),
            lambda: slots.new(name=armature.name),
        ]
        for make_slot in create_attempts:
            try:
                new_slot = make_slot()
                anim_data.action_slot = new_slot
                return action, anim_data.action_slot
            except Exception:
                continue

    return action, None


def infer_fcurve_group_name(data_path, fallback_group_name):
    """Leitet sinnvollen FCurve-Gruppennamen aus data_path ab."""
    prefix = 'pose.bones["'
    if data_path.startswith(prefix):
        rest = data_path[len(prefix):]
        end_idx = rest.find('"]')
        if end_idx > 0:
            return rest[:end_idx]

    if data_path in {'location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle'}:
        return "root"

    return fallback_group_name


def set_new_fcurve(armature, data_path, index, group_name):
    """Erzeugt bei Bedarf eine neue FCurve im passenden API-Pfad."""
    existing = get_fcurve(armature, data_path, index)
    if existing:
        return existing

    action, slot = ensure_action_and_slot(armature)
    inferred_group_name = infer_fcurve_group_name(data_path, group_name)

    # Bevorzugt Layered Action API verwenden.
    if hasattr(action, "layers"):
        if slot is None:
            raise RuntimeError("Layered Action aktiv, aber kein gueltiger action_slot vorhanden")
        try:
            channelbag = bpy_extras.anim_utils.action_ensure_channelbag_for_slot(action, slot)
            return channelbag.fcurves.new(data_path, index=index, group_name=inferred_group_name)
        except RuntimeError:
            raise

    # Fallback fuer Actions ohne gueltigen Slot.
    if hasattr(action, "fcurves"):
        return action.fcurves.new(data_path, index=index, action_group=inferred_group_name)

    raise RuntimeError("Could not create FCurve: no valid action slot and no legacy fcurve API available")


def map_chain_bones_nm(chain_source, chain_target):
    """Mappt Zielknochen auf Sourceknochen bei ungleichen Kettenlaengen (n:m).

    Lineares Index-Mapping ueber normierte Kettenposition:
    t = i_tgt / (N_tgt - 1)
    i_src = round(t * (N_src - 1))
    """
    if not chain_source or not chain_target:
        return []

    if len(chain_source) == 1:
        return [(chain_source[0], bone_t) for bone_t in chain_target]

    if len(chain_target) == 1:
        return [(chain_source[0], chain_target[0])]

    pairs = []
    src_last = len(chain_source) - 1
    tgt_last = len(chain_target) - 1

    for tgt_idx, bone_t in enumerate(chain_target):
        t = tgt_idx / tgt_last
        src_idx = int(round(t * src_last))
        src_idx = max(0, min(src_idx, src_last))
        pairs.append((chain_source[src_idx], bone_t))

    return pairs


def _get_pose_bone_case_insensitive(armature_obj, bone_name):
    """Case-insensitive Bone-Lookup als robustes Convenience-Helper."""
    if armature_obj is None or armature_obj.type != 'ARMATURE' or not bone_name:
        return None

    pose_bones = armature_obj.pose.bones
    direct = pose_bones.get(bone_name)
    if direct:
        return direct

    lower_name = bone_name.lower()
    for pose_bone in pose_bones:
        if pose_bone.name.lower() == lower_name:
            return pose_bone
    return None



def _rest_distance_between_bones(armature_obj, bone_a, bone_b):
    """Euklidische Distanz zweier Restpose-Headpunkte in Weltkoordinaten."""
    if armature_obj is None or bone_a is None or bone_b is None:
        return None
    head_a = armature_obj.matrix_world @ bone_a.bone.head_local
    head_b = None
    if isinstance(bone_b, bpy.types.Bone):
        head_b = armature_obj.matrix_world @ bone_b.head_local
    else:
        head_b = armature_obj.matrix_world @ bone_b.bone.head_local
    return (head_b - head_a).length


def _bone_rest_length_local(pose_bone):
    """Lokale Bone-Laenge in Restpose: ||tail_local - head_local||."""
    if pose_bone is None:
        return None
    head_l = pose_bone.bone.head_local
    tail_l = pose_bone.bone.tail_local
    return (tail_l - head_l).length


def compute_location_scale_for_bone_pair(armature_source, armature_target, bone_s, bone_t):
    """Berechnet Translation-Skalierung zwischen Source- und Target-Bone.

    Formel:
    scale = ||bone_t|| / ||bone_s||
    """
    src_len = _bone_rest_length_local(bone_s)
    tgt_len = _bone_rest_length_local(bone_t)
    if src_len is None or tgt_len is None:
        return 1.0
    if src_len <= 1e-8 or tgt_len <= 1e-8:
        return 1.0

    ratio = tgt_len / src_len
    return ratio
   # return max(0.1, min(10.0, ratio))


def compute_bone_motion_scale(armature_source, armature_target, bone_s, bone_t):
    """Berechnet Skalierung fuer Bone-Translation/Rotation aus anthropometrischer Referenz.

    Formel:
    s = d_tgt(root, bone) / d_src(root, bone)
    """
    src_root_dist = None
    tgt_root_dist = None
    if bone_s.bone.parent is None:
        bone_s_parent_loc = Vector((0.0, 0.0, 0.0))
        scr_root_dist = armature_source.matrix_world @ bone_s.bone.head_local
        src_root_dist = (scr_root_dist - bone_s_parent_loc).length
    else:
        src_root_dist = _rest_distance_between_bones(armature_source, bone_s, bone_s.bone.parent)

    if bone_t.bone.parent is None:
        bone_t_parent_loc = Vector((0.0, 0.0, 0.0))
        tgt_root_dist = armature_target.matrix_world @ bone_t.bone.head_local
        tgt_root_dist = (tgt_root_dist - bone_t_parent_loc).length
    else:
        tgt_root_dist = _rest_distance_between_bones(armature_target, bone_t, bone_t.bone.parent)

   # src_root_dist = _rest_distance_between_bones(armature_source, bone_s, bone_s.bone.parent)
   # tgt_root_dist = _rest_distance_between_bones(armature_target, bone_t, bone_t.bone.parent)

    if src_root_dist is None or tgt_root_dist is None:
        return 1.0
    if src_root_dist <= 1e-8 or tgt_root_dist <= 1e-8:
        return 1.0

    return tgt_root_dist / src_root_dist


def compute_root_motion_scale(armature_source, armature_target, root_source_bone, root_target_bone, spine_name="pelvis"):
    """Skalierung fuer Root-Objekttranslation aus anthropometrischer Referenz.

    Formel:
    s_root = d_tgt(root, spine) / d_src(root, spine)
    """
    src_spine = _get_pose_bone_case_insensitive(armature_source, spine_name)
    tgt_spine = _get_pose_bone_case_insensitive(armature_target, spine_name)

    src_dist = _rest_distance_between_bones(armature_source, root_source_bone, src_spine)
    tgt_dist = _rest_distance_between_bones(armature_target, root_target_bone, tgt_spine)

    if src_dist is None or tgt_dist is None:
        return 1.0
    if src_dist <= 1e-8 or tgt_dist <= 1e-8:
        return 1.0

    return tgt_dist / src_dist


def apply_offset_to_fcurves_copy(armature_source, armature_target, chain_source, chain_target, source_root="", target_root="", scale_enum="BONE"):
    """Fuehrt Translation/Rotation-Retargeting fuer alle gemappten Bonepaare aus."""
    root_done = False

    for bone_s, bone_t in map_chain_bones_nm(chain_source, chain_target):
        # Simple Regel: Root ist nur der Bone mit Name "root".

        is_root_by_name = False
        if source_root != "" and target_root != "":
            is_root_by_name = (bone_t.name.lower() == target_root.lower()) and (bone_s.name.lower() == source_root.lower())
            if is_root_by_name:
                if not root_done:
                    root_motion_scale = compute_root_motion_scale(
                        armature_source,
                        armature_target,
                        bone_s,
                        bone_t,
                        spine_name="pelvis",
                    )
                    apply_root_object_offset(
                        armature_source,
                        armature_target,
                        translation_scale=root_motion_scale,
                        spine_name=None,
                        use_target_root_for_rotation=True,
                        use_source_root_for_rotation=True,
                    )
                    root_done = True
                continue


        apply_location_offset(armature_source, armature_target, bone_s, bone_t, scale_enum=scale_enum)
        apply_rotation_offset(armature_source, armature_target, bone_s, bone_t)







def apply_root_object_offset(armature_source, armature_target, translation_scale=1.0, spine_name="pelvis", use_target_root_for_rotation = True, use_source_root_for_rotation = True):
    """Kopiert Root-Objektanimation (Location + Rotation) auf das Target.

    Translation:
    p_tgt(frame) = translation_scale * p_src(frame)

    Rotation:
    - Source-Kanaele (Euler/Quat/AxisAngle) werden in Quaternion ausgewertet.
    - Quaternion-Zeichen wird pro Frame kontinuierlich gehalten (dot >= 0).
    """

    # Root liegt hier auf Objekt-Ebene (location/rotation_euler), nicht in pose.bones.
    fcurves_src_loc = [get_fcurve(armature_source, 'location', i) for i in range(3)]
    fcurves_tgt_loc = [get_fcurve(armature_target, 'location', i) for i in range(3)]

    for i in range(3):
        if not fcurves_tgt_loc[i]:
            fcurves_tgt_loc[i] = set_new_fcurve(armature_target, 'location', i, "Location")
        fcurves_tgt_loc[i].keyframe_points.clear()

    loc_frames = set()
    for fc in fcurves_src_loc:
        if fc:
            loc_frames.update([kp.co.x for kp in fc.keyframe_points])

    for frame in sorted(loc_frames):
        loc = [fcurves_src_loc[i].evaluate(frame) if fcurves_src_loc[i] else 0.0 for i in range(3)]
        loc = [axis_value * translation_scale for axis_value in loc]
        for i in range(3):
            fcurves_tgt_loc[i].keyframe_points.insert(frame, loc[i], options={'NEEDED'})

    for fc in fcurves_tgt_loc:
        fc.update()

    source_mode, fcurves_src_rot = get_source_rotation_channels(armature_source, spine_name, use_object_root=use_source_root_for_rotation)
    if source_mode is None:
        print("Keine Root-Rotations-FCurves auf Objekt-Ebene gefunden (rotation_euler/rotation_quaternion).")
        return

    euler_order = armature_source.rotation_mode if armature_source.rotation_mode in {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'} else 'XYZ'
    target_mode = "EULER" if source_mode == "EULER" else "QUATERNION"
    armature_target.rotation_mode = euler_order if target_mode == "EULER" else 'QUATERNION'
    fcurves_tgt_rot = ensure_target_rotation_curves(armature_target, spine_name, target_mode, use_object_root=use_target_root_for_rotation)

    frames = set()
    for fc in fcurves_src_rot:
        if fc:
            frames.update([kp.co.x for kp in fc.keyframe_points])

    prev_q = None
    for frame in sorted(frames):
        q = evaluate_source_quaternion(source_mode, fcurves_src_rot, frame, euler_order)
        if prev_q and prev_q.dot(q) < 0:
            q = -q
        prev_q = q.copy()
        write_target_rotation_key(fcurves_tgt_rot, target_mode, frame, q, euler_order)

    for fc in fcurves_tgt_rot:
        fc.update()


def apply_location_offset(armature_source, armature_target, bone_s, bone_t, scale_enum="BONE"):
    """Retargetet lokale Bone-Translation von Source auf Target.

    Schritte pro Frame:
    1) v_src <- Source-Location-FCurve
    2) v_src <- scale * v_src
    3) v_tgt = q_tgt_rest^{-1} * (q_src_rest * v_src)

    Dadurch wird die Translation in das lokale Achsensystem des Zielknochens
    ueberfuehrt.
    """
    q_src_local_rest = bone_s.bone.matrix_local.to_quaternion()
    q_tgt_local_rest = bone_t.bone.matrix_local.to_quaternion()
    q_tgt_local_rest_inv = q_tgt_local_rest.inverted()

    location_scale = 1.0
    bone_scale = compute_location_scale_for_bone_pair(armature_source, armature_target, bone_s, bone_t)
    chain_scale= compute_bone_motion_scale(armature_source, armature_target, bone_s, bone_t)

    print(bone_scale, chain_scale)


    if scale_enum == 'BONE':
        location_scale = bone_scale
    elif scale_enum == 'CHAIN':
        location_scale = chain_scale
    else:
       # location_scale = bone_scale * chain_scale
        location_scale = math.sqrt(bone_scale * chain_scale)


    fcurves_a_loc = [get_fcurve(armature_source, f'pose.bones["{bone_s.name}"].location', i) for i in range(3)]
    if not any(fcurves_a_loc):
        return

    data_path = f'pose.bones["{bone_t.name}"].location'
    fcurves_b_loc = [get_fcurve(armature_target, data_path, i) for i in range(3)]
    for i in range(3):
        if not fcurves_b_loc[i]:
            fcurves_b_loc[i] = set_new_fcurve(armature_target, data_path, i, "Location")
        fcurves_b_loc[i].keyframe_points.clear()

    frames = set()
    for fc in fcurves_a_loc:
        if fc:
            frames.update([kp.co.x for kp in fc.keyframe_points])

    for frame in sorted(frames):
        src_local = Vector((
            fcurves_a_loc[0].evaluate(frame) if fcurves_a_loc[0] else 0.0,
            fcurves_a_loc[1].evaluate(frame) if fcurves_a_loc[1] else 0.0,
            fcurves_a_loc[2].evaluate(frame) if fcurves_a_loc[2] else 0.0,
        )) * location_scale
        # Basiswechsel Source-Restachsen -> Target-Restachsen.
        tgt_local = q_tgt_local_rest_inv @ (q_src_local_rest @ src_local)

        for axis_idx in range(3):
            fcurves_b_loc[axis_idx].keyframe_points.insert(frame, tgt_local[axis_idx], options={'NEEDED'})

    for fc in fcurves_b_loc:
        fc.update()





def bone_rest_world_quaternion(armature_obj, pose_bone):
    """Restpose-Quaternion des Knochens in Armature-Space.

    Entspricht im Referenzcode der T-Pose in Model-Space, aber ohne
    Abhaengigkeit von der Objekt-World-Rotation in Blender.
    """
    _ = armature_obj
    return pose_bone.bone.matrix_local.to_quaternion()


def parent_rest_world_quaternion(armature_obj, pose_bone):
    """Restpose-Quaternion des Elternknochens in Armature-Space.

    Entspricht im Referenzcode dem parent.world.rot bzw. root_offset.rot
    innerhalb des Skelett-Modellraums.
    """
    _ = armature_obj
    parent = pose_bone.parent
    if parent is None:
        return Quaternion((1.0, 0.0, 0.0, 0.0))
    return parent.bone.matrix_local.to_quaternion()


def bone_rest_local_quaternion(pose_bone):
    """Lokale Restpose-Rotation relativ zum Parent (Armature-Space)."""
    parent = pose_bone.parent
    bone_rest_mat = pose_bone.bone.matrix_local
    if parent is None:
        return bone_rest_mat.to_quaternion()
    parent_rest_mat = parent.bone.matrix_local
    return (parent_rest_mat.inverted() @ bone_rest_mat).to_quaternion()


def find_rotation_channels(armature, base_path=""):
    """Findet vorhandene Rotations-FCurves und deren Darstellungsmodus."""
    prefix = f"{base_path}." if base_path else ""
    channel_specs = [
        ("EULER", f"{prefix}rotation_euler", 3),
        ("QUATERNION", f"{prefix}rotation_quaternion", 4),
        ("AXIS_ANGLE", f"{prefix}rotation_axis_angle", 4),
    ]

    for mode, data_path, count in channel_specs:
        curves = [get_fcurve(armature, data_path, i) for i in range(count)]
        if any(curves):
            return mode, curves

    return None, []


def get_source_rotation_channels(armature, bone_name, use_object_root=False):
    """Liest Rotationskanaele fuer Bone oder Root-Objekt."""
    if use_object_root:
        if find_rotation_channels(armature)[0] is not None:
            return find_rotation_channels(armature)

    if not bone_name:
        return None, []

    return find_rotation_channels(armature, f'pose.bones["{bone_name}"]')

# in quatarnionen umwandeln :D zur weiterberechnung
def evaluate_source_quaternion(rotation_mode, fcurves, frame, euler_order='XYZ'):
    if rotation_mode == "QUATERNION":
        values = [
            fcurves[i].evaluate(frame) if fcurves[i] else (1.0 if i == 0 else 0.0)
            for i in range(4)
        ]
        q = Quaternion(values)
        q.normalize()
        return q

    if rotation_mode == "EULER":
        values = [
            fcurves[i].evaluate(frame) if fcurves[i] else 0.0
            for i in range(3)
        ]
        q = Euler(values, euler_order).to_quaternion()
        q.normalize()
        return q

    if rotation_mode == "AXIS_ANGLE":
        angle = fcurves[0].evaluate(frame) if fcurves[0] else 0.0
        axis = Vector((
            fcurves[1].evaluate(frame) if fcurves[1] else 0.0,
            fcurves[2].evaluate(frame) if fcurves[2] else 0.0,
            fcurves[3].evaluate(frame) if fcurves[3] else 1.0,
        ))
        if axis.length_squared == 0.0:
            return Quaternion((1.0, 0.0, 0.0, 0.0))
        axis.normalize()
        q = Quaternion(axis, angle)
        q.normalize()
        return q

    return Quaternion((1.0, 0.0, 0.0, 0.0))


def ensure_target_rotation_curves(armature_target, bone_t, target_mode, use_object_root=False):
    """Stellt Ziel-Rotations-FCurves bereit und leert alte Keys."""
    if use_object_root:
        if target_mode == "EULER":
            curves = [get_fcurve(armature_target, 'rotation_euler', i) for i in range(3)]
            for i in range(3):
                if not curves[i]:
                    curves[i] = set_new_fcurve(armature_target, 'rotation_euler', i, "Rotation")
                curves[i].keyframe_points.clear()
            return curves

        curves = [get_fcurve(armature_target, 'rotation_quaternion', i) for i in range(4)]
        for i in range(4):
            if not curves[i]:
                curves[i] = set_new_fcurve(armature_target, 'rotation_quaternion', i, "Rotation")
            curves[i].keyframe_points.clear()
        return curves

    if target_mode == "EULER":
        data_path = ""
        if isinstance(bone_t, str):
            data_path = f'pose.bones["{bone_t}"].rotation_euler'
        else:
            data_path = f'pose.bones["{bone_t.name}"].rotation_euler'

        curves = [get_fcurve(armature_target, data_path, i) for i in range(3)]
        for i in range(3):
            if not curves[i]:
                curves[i] = set_new_fcurve(armature_target, data_path, i, "Rotation")
            curves[i].keyframe_points.clear()
        return curves

    data_path = ""
    if isinstance(bone_t, str):
        data_path = f'pose.bones["{bone_t}"].rotation_quaternion'
    else:
        data_path = f'pose.bones["{bone_t.name}"].rotation_quaternion'
    curves = [get_fcurve(armature_target, data_path, i) for i in range(4)]
    for i in range(4):
        if not curves[i]:
            curves[i] = set_new_fcurve(armature_target, data_path, i, "Rotation")
        curves[i].keyframe_points.clear()
    return curves


def write_target_rotation_key(curves, target_mode, frame, q_tgt_local, euler_order):
    """Schreibt pro Frame entweder Euler- oder Quaternion-Keyframes."""
    if target_mode == "EULER":
        e = q_tgt_local.to_euler(euler_order)
        curves[0].keyframe_points.insert(frame, e.x, options={'NEEDED'})
        curves[1].keyframe_points.insert(frame, e.y, options={'NEEDED'})
        curves[2].keyframe_points.insert(frame, e.z, options={'NEEDED'})
        return

    q_tgt_local.normalize()
    curves[0].keyframe_points.insert(frame, q_tgt_local.w, options={'NEEDED'})
    curves[1].keyframe_points.insert(frame, q_tgt_local.x, options={'NEEDED'})
    curves[2].keyframe_points.insert(frame, q_tgt_local.y, options={'NEEDED'})
    curves[3].keyframe_points.insert(frame, q_tgt_local.z, options={'NEEDED'})



def apply_rotation_offset(armature_source, armature_target, bone_s, bone_t):
    """Retargetet Bone-Rotation mit Restpose-konsistenter Quaternion-Mathematik.

    Kernidee:
    - Source-FCurve liefert Delta relativ zur Source-Restpose.
    - Delta wird zu absoluter lokaler Pose gemacht.
    - In World/Armature-Space auf Target-Restorientierung gemappt.
    - Zurueck in Target-Delta relativ zur Target-Restpose.

    Schematische Formeln:
    q_convert = q_src_rest_world^{-1} * q_tgt_rest_world
    q_src_local_abs = q_src_rest_local * q_src_delta
    q_src_pose_world = q_src_parent_rest_world * q_src_local_abs
    q_tgt_pose_world = q_src_pose_world * q_convert
    q_tgt_local_abs = q_tgt_parent_rest_world^{-1} * q_tgt_pose_world
    q_tgt_delta = q_tgt_rest_local^{-1} * q_tgt_local_abs

    Zusaetzlich:
    - q_static_rest_fix entfernt konstante Restpose-Offset-Fehler.
    - Vorzeichenkontinuitaet verhindert 180-Grad-Quaternion-Flips.
    """
    source_mode, fcurves_a_rot = get_source_rotation_channels(armature_source, bone_s.name)

    # Keine Rotationsdaten vorhanden.
    if source_mode is None:
        print(f"Keine Rotations-FCurves fuer Bone '{bone_s.name}' gefunden (quaternion/euler/axis_angle).")
        return

    euler_order = bone_s.rotation_mode if bone_s.rotation_mode in {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'} else 'XYZ'
    target_mode = "QUATERNION"
    bone_t.rotation_mode = 'QUATERNION'
    fcurves_b_rot = ensure_target_rotation_curves(armature_target, bone_t, target_mode)



    q_src_rest_world = bone_rest_world_quaternion(armature_source, bone_s)
    q_src_parent_rest_world = parent_rest_world_quaternion(armature_source, bone_s)
    q_tgt_rest_world = bone_rest_world_quaternion(armature_target, bone_t)
    q_tgt_parent_rest_world = parent_rest_world_quaternion(armature_target, bone_t)
    q_src_rest_local = bone_rest_local_quaternion(bone_s)
    q_tgt_rest_local = bone_rest_local_quaternion(bone_t)
    q_tgt_rest_local_inv = q_tgt_rest_local.inverted()

    # Umrechnungsrotation Source-Rest->Target-Rest im Armature-Space.
    q_convert = q_src_rest_world.inverted() @ q_tgt_rest_world
    q_convert.normalize()

    #Der Block berechnet eine konstante Korrektur‑Quaternion, die systematische Restpose‑Unterschiede (z.B. 180°-Offsets oder Achsenverdrehungen)
    #zwischen Source und Target aufhebt, damit die später übertragenen Animations‑Rotationen nicht dauerhaft versetzt oder gedreht erscheinen.
    q_src_rest_pose_world = q_src_parent_rest_world @ q_src_rest_local
    q_tgt_rest_pose_world_from_convert = q_src_rest_pose_world @ q_convert
    q_tgt_rest_local_abs_from_convert = q_tgt_parent_rest_world.inverted() @ q_tgt_rest_pose_world_from_convert
    q_tgt_rest_local_abs_from_convert.normalize()
    q_tgt_rest_delta_from_convert = q_tgt_rest_local_inv @ q_tgt_rest_local_abs_from_convert
    q_tgt_rest_delta_from_convert.normalize()
    q_static_rest_fix = q_tgt_rest_delta_from_convert.inverted()
    q_static_rest_fix.normalize()

    frames = set()
    for fc in fcurves_a_rot:
        if fc:
            frames.update([kp.co.x for kp in fc.keyframe_points])

    if not frames:
        return

    prev_q_tgt_local = None

    for frame in sorted(frames):
        q_a_local = evaluate_source_quaternion(source_mode, fcurves_a_rot, frame, euler_order)

        # Blender-FCurve liefert Delta zur Restpose; fuer die Referenzformel
        # brauchen wir absolute lokale Pose-Rotation.
        q_src_local_abs = q_src_rest_local @ q_a_local
        q_src_local_abs.normalize()

        q_src_pose_world = q_src_parent_rest_world @ q_src_local_abs

        q_convert_use = q_convert
        if q_src_pose_world.dot(q_src_rest_world) < 0:
            q_convert_use = -q_convert

        # Pose in Zielraum ueberfuehren.
        q_tgt_pose_world = q_src_pose_world @ q_convert_use
        q_tgt_local_abs = q_tgt_parent_rest_world.inverted() @ q_tgt_pose_world
        q_tgt_local_abs.normalize()

        # Zurueck in Blender-Delta (relativ zur Restpose des Zielknochens).
        q_tgt_local = q_tgt_rest_local_inv @ q_tgt_local_abs
        q_tgt_local = q_static_rest_fix @ q_tgt_local
        q_tgt_local.normalize()

        # Quaternion-Signal kontinuierlich halten, um 180-Grad-Flips zwischen Frames zu vermeiden.
        if prev_q_tgt_local and prev_q_tgt_local.dot(q_tgt_local) < 0:
            q_tgt_local = -q_tgt_local
        prev_q_tgt_local = q_tgt_local.copy()

        write_target_rotation_key(fcurves_b_rot, target_mode, frame, q_tgt_local, euler_order)

    for b_rot in fcurves_b_rot:
        b_rot.update()











def retarget_animation(source_armature, target_armature, chain_source, chain_target, source_root="", target_root="", scale_enum="BONE"):
    """Einstiegspunkt fuer das eigentliche Retargeting einer Bone-Kette."""
    if not chain_source or not chain_target:
        print("Source- oder Target-Kette ist leer")
        return

    apply_offset_to_fcurves_copy(source_armature, target_armature, chain_source, chain_target, source_root, target_root, scale_enum)
