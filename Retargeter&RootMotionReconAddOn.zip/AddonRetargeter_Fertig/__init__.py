# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "ADDON_NAME",
    "author": "AUTHOR_NAME",
    "description": "",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Generic",
}
import bpy
from . import auto_load
from .retargering import *

auto_load.init()


classes = (
    RootMotionPanel,
    MyPanel,
    ApplyRootMotionOperator,
    AddOperator,
    RemoveChainOperator,
    CalculateRetargeting,
    Armature,
    Chain
)

def register():
  #  auto_load.register()
    for cls in reversed(classes):
        bpy.utils.register_class(cls)

    bpy.types.Scene.armature = bpy.props.PointerProperty(type=Armature)
    bpy.types.Scene.chain = bpy.props.PointerProperty(type=Chain)


def unregister():
   # auto_load.unregister()
    for cls in classes:
        bpy.utils.unregister_class(cls)

    if hasattr(bpy.types.Scene, "armature"):
        del bpy.types.Scene.armature
    if hasattr(bpy.types.Scene, "chain"):
        del bpy.types.Scene.chain